//
//  ViewController.m
//  导航栏颜色变化
//
//  Created by wangle on 17/6/11.
//  Copyright © 2017年 wangle. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>{
    UITableView * _tableView;
    UIImageView * imageView;
    UIView * navView;
}

@property (nonatomic, assign)CGRect rect;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor whiteColor];
    self.automaticallyAdjustsScrollViewInsets = NO;
    //首先是设置info.plist 文件：将View controller-based status bar appearance 的值设置为NO。
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;

    [self setUI];
}

- (void)setUI {
    
    
    imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 200)];
    imageView.image = [UIImage imageNamed:@"QQ20170612-000054"];
    _rect = imageView.frame;
    [self.view addSubview:imageView];

    navView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 64)];
    navView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:navView];
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 64, self.view.frame.size.width, self.view.frame.size.height-66) style:UITableViewStylePlain];
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.rowHeight = 35;
    //[_tableView insertSubview:imageView atIndex:0];
    UIView * headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 100)];
    headView.backgroundColor = [UIColor clearColor];
    _tableView.tableHeaderView = headView;
    
    [self.view addSubview:_tableView];
}


- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    CGFloat yOffset = scrollView.contentOffset.y;
    NSLog(@"%f",yOffset);

    
    if (yOffset < 64) {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;

        navView.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:yOffset/64];
    } else {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
        

        navView.backgroundColor = [UIColor whiteColor];

    }
    
    
    if (yOffset > 0) {
        imageView.frame = ({
            CGRect frame = _rect;
            frame.origin.y = _rect.origin.y - yOffset;
            frame;
        });

    }else {
        
        imageView.frame = ({
            CGRect frame = _rect;
            frame.size.height = _rect.size.height - yOffset;
            frame.size.width = frame.size.height*self.view.frame.size.width/200;
            frame.origin.x = _rect.origin.x - (frame.size.width - _rect.size.width)/2;
            frame;
        });
        
    }
    
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 30;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    cell.textLabel.text = @"呵呵额呵";
    return cell;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
